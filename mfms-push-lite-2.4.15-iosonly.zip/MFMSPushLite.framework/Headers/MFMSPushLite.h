//
//  MFMSPushLite.h
//  MFMSPushLite
//
//  Created by Anton Bulankin on 08.06.2018.
//  Copyright © 2018 MFM Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MFMSPushLite.
FOUNDATION_EXPORT double MFMSPushLiteVersionNumber;

//! Project version string for MFMSPushLite.
FOUNDATION_EXPORT const unsigned char MFMSPushLiteVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MFMSPushLite/PublicHeader.h>
